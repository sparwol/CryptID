﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cryptid.Forms
{
    public partial class FormTools : System.Windows.Forms.Form
    {
        public FormTools()
        {
            InitializeComponent();
        }
        public void OpenChildForm(Form childForm, object buttonSend)
        {
            
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            
            childForm.BringToFront();
            childForm.Show();
            
        }
        private void buttonPassGen_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FormGenPass(), sender);
            
        }
    }
}
