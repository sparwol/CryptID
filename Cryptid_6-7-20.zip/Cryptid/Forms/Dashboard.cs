﻿/*
 * ----------------------------------
 *          CRYPTID 
 *        
 *      File Encryption
 *    
 *    by Sean Parrott-Wolfe
 *    Last updated 6/7/20
 * ----------------------------------
 *  Estimated Time for Incremental: 3 hrs
 */

using System;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;
using Cryptid.Forms;

namespace Cryptid
{
    public partial class Dashboard : Form
    {
        // Declare CspParmeters and RsaCryptoServiceProvider
        // objects with global scope of your Form class.
        CspParameters cspp = new CspParameters();
        //RSACryptoServiceProvider rsa;

        // Path variables for source, encryption, and
        // decryption folders. Must end with a backslash.
        public const string EncrFolder = @"c:\Encrypt\";
        public const string DecrFolder = @"c:\Decrypt\";
        public const string SrcFolder = @"c:\docs\";

        // Public key file
        public const string PubKeyFile = @"c:\encrypt\rsaPublicKey.txt";

        // Key container name for
        // private/public key value pair.
        const string keyName = "RSA Key";


        private Form activeForm;

        public Dashboard()
        {
            InitializeComponent();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void OpenChildForm(Form childForm, object buttonSend)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelMain.Controls.Add(childForm);
            this.panelMain.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            labelTitle.Text = childForm.Text;

        }

        private void buttonAes_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormAes(), sender);
            panel2.Height = buttonAes.Height;
            panel2.Top = buttonAes.Top;
            labelTitle.Text = buttonAes.Text;
        }

        private void buttonTwofish_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormTwofish(), sender);
            panel2.Height = buttonTwofish.Height;
            panel2.Top = buttonTwofish.Top;
        }

        private void buttonKeys_Click(object sender, EventArgs e)
        {
            
            if(panelKeys.Visible != true)
            {
                panelKeys.Visible = true;
            }
            else if (panelKeys.Visible == true)
            {
                panelKeys.Visible = false;
            }
        }

        private void buttonTools_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormTools(), sender);
            panel2.Height = buttonTools.Height;
            panel2.Top = buttonTools.Top;
        }

        private void buttonExit_Click(object sender, EventArgs e)
		{
            DialogResult dialog = MessageBox.Show("Do you really want to exit?", "Exit?", MessageBoxButtons.OKCancel);
            if (dialog == DialogResult.OK)
            {
                MessageBox.Show("Goodbye!");
                Application.Exit();
            }
            
        }

        // Key Management
        private void buttonCreateAsmKeys_Click(object sender, System.EventArgs e)
        {
            // Stores a key pair in the key container.
            cspp.KeyContainerName = keyName;
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(cspp);
            rsa.PersistKeyInCsp = true;
            if (rsa.PublicOnly == true)
                labelKey.Text = "RSA Key: " + cspp.KeyContainerName + " - Public Only";
            else
                labelKey.Text = "RSA Key: " + cspp.KeyContainerName + " - Full Key Pair";
        }

        private void buttonExportPublicKey_Click(object sender, System.EventArgs e)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(cspp);
            // Save the public key created by the RSA
            // to a file. Caution, persisting the
            // key to a file is a security risk.
            Directory.CreateDirectory(EncrFolder);
            StreamWriter sw = new StreamWriter(PubKeyFile, false);
            sw.Write(rsa.ToXmlString(false));
            sw.Close();
        }
 

        private void buttonImportPublicKey_Click(object sender, System.EventArgs e)
        {
            StreamReader sr = new StreamReader(PubKeyFile);
            cspp.KeyContainerName = keyName;
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(cspp);
            string keytxt = sr.ReadToEnd();
            rsa.FromXmlString(keytxt);
            rsa.PersistKeyInCsp = true;
            if (rsa.PublicOnly == true)
                labelKey.Text = "RSA Key: " + cspp.KeyContainerName + " - Public Only";
            else
                labelKey.Text = "RSA Key: " + cspp.KeyContainerName + " - Full Key Pair";
            sr.Close();
        }

        private void buttonGetPrivateKey_Click(object sender, EventArgs e)
        {
            cspp.KeyContainerName = keyName;
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(cspp);
            rsa.PersistKeyInCsp = true;

            if (rsa.PublicOnly == true)
                labelKey.Text = "RSA Key: " + cspp.KeyContainerName + " - Public Only";
            else
                labelKey.Text = "RSA Key: " + cspp.KeyContainerName + " - Full Key Pair";
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }
    }
}