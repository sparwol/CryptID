﻿namespace Cryptid.Forms
{
    partial class FormEllipticCurve
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelEllipticCurve = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelEllipticCurve
            // 
            this.labelEllipticCurve.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelEllipticCurve.AutoSize = true;
            this.labelEllipticCurve.Font = new System.Drawing.Font("Gill Sans MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEllipticCurve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelEllipticCurve.Location = new System.Drawing.Point(217, 149);
            this.labelEllipticCurve.Name = "labelEllipticCurve";
            this.labelEllipticCurve.Size = new System.Drawing.Size(0, 45);
            this.labelEllipticCurve.TabIndex = 0;
            // 
            // FormEllipticCurve
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(655, 401);
            this.Controls.Add(this.labelEllipticCurve);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormEllipticCurve";
            this.Text = "Elliptic Curve";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelEllipticCurve;
    }
}