﻿/*
 * ----------------------------------
 *          CRYPTID 
 *        
 *      File Encryption
 *    
 *    by Sean Parrott-Wolfe
 *    Last updated 6/15/20
 * ----------------------------------
 *  Estimated Time for Incremental: 3 hrs
 */

using System;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;


namespace Cryptid
{
    public partial class Dashboard : Form
    {
        
        // Declare CspParmeters and RsaCryptoServiceProvider
        // objects with global scope of your Form class.
        CspParameters cspp = new CspParameters();
        //RSACryptoServiceProvider rsa;

        // Path variables for source, encryption, and
        // decryption folders. Must end with a backslash.
        public const string EncrFolder = @"c:\Encrypt\";
        public const string DecrFolder = @"c:\Decrypt\";
        public const string SrcFolder = @"c:\docs\";

        // Public key file
        public const string PubKeyFile = @"c:\encrypt\rsaPublicKey.txt";

        // Key container name for
        // private/public key value pair.
        const string keyName = "RSA Key";

        

        private Form activeForm;

        public Dashboard()
        {
            InitializeComponent();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void OpenChildForm(Form childForm, object buttonSend)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelMain.Controls.Add(childForm);
            this.panelMain.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            labelTitle.Text = childForm.Text;

        }

        private void buttonAes_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormAes(), sender);
            panel2.Height = buttonAes.Height;
            panel2.Top = buttonAes.Top;
            labelTitle.Text = buttonAes.Text;
        }

        private void buttonTwofish_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormTwofish(), sender);
            panel2.Height = buttonTwofish.Height;
            panel2.Top = buttonTwofish.Top;
        }

        private void buttonKeys_Click(object sender, EventArgs e)
        {
            
            if(panelKeys.Visible != true)
            {
                panelKeys.Visible = true;
            }
            else if (panelKeys.Visible == true)
            {
                panelKeys.Visible = false;
            }
        }

        private void buttonTools_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormGenPass(), sender);
            panel2.Height = buttonTools.Height;
            panel2.Top = buttonTools.Top;
        }

        private void buttonExit_Click(object sender, EventArgs e)
		{
            DialogResult dialog = MessageBox.Show("Do you really want to exit?", "Exit?", MessageBoxButtons.OKCancel);
            if (dialog == DialogResult.OK)
            {
                MessageBox.Show("Goodbye!");
                Application.Exit();
            }
            
        }

        // Key Management
        private void buttonCreateAsmKeys_Click(object sender, System.EventArgs e)
        {
            // Stores a key pair in the key container.
            cspp.KeyContainerName = keyName;
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(cspp);
            rsa.PersistKeyInCsp = true;
            if (rsa.PublicOnly == true)
                labelPrivate.Text = "RSA Public Only";
            else
                labelPrivate.Text = "RSA Full Key Pair";
        }

        private void buttonExportPublicKey_Click(object sender, System.EventArgs e)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(cspp);
            // Save the public key created by the RSA
            // to a file. Caution, persisting the
            // key to a file is a security risk.
            Directory.CreateDirectory(EncrFolder);
            StreamWriter sw = new StreamWriter(PubKeyFile, false);
            sw.Write(rsa.ToXmlString(false));
            sw.Close();
        }
 

        private void buttonImportPublicKey_Click(object sender, System.EventArgs e)
        {
            StreamReader sr = new StreamReader(PubKeyFile);
            cspp.KeyContainerName = keyName;
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(cspp);
            string keytxt = sr.ReadToEnd();
            rsa.FromXmlString(keytxt);
            rsa.PersistKeyInCsp = true;
            if (rsa.PublicOnly == true)
            {
                
                labelPrivate.Text = "RSA Public Only";
            }
            else
            {
                
                labelPrivate.Text = "RSA Full Key Pair";
            }
            sr.Close();
        }

        private void buttonGetPrivateKey_Click(object sender, EventArgs e)
        {
            cspp.KeyContainerName = keyName;
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(cspp);
            rsa.PersistKeyInCsp = true;
            if (rsa.PublicOnly == true)
            {
                labelPrivate.Text = "RSA Public Only";
            }
            else
            {
                labelPrivate.Text = "RSA Full Key Pair";
            }
        }

        

        private void GeneratePKeys(int intSize)
        {

            //Generating p-128 keys 128 specifies strength
            var keyPair = GenerateKeys(intSize);
            TextWriter textWriter = new StringWriter();
            Org.BouncyCastle.OpenSsl.PemWriter pemWriter = new Org.BouncyCastle.OpenSsl.PemWriter(textWriter);
            pemWriter.WriteObject(keyPair.Private);
            pemWriter.Writer.Flush();
            string privateKey = textWriter.ToString();
            ECPrivateKeyParameters privateKeyParam = (ECPrivateKeyParameters)keyPair.Private;
            

            textWriter = new StringWriter();
            pemWriter = new Org.BouncyCastle.OpenSsl.PemWriter(textWriter);
            pemWriter.WriteObject(keyPair.Public);
            pemWriter.Writer.Flush();

            ECPublicKeyParameters publicKeyParam = (ECPublicKeyParameters)keyPair.Public;

            string publickey = textWriter.ToString();
        }

        public AsymmetricCipherKeyPair GenerateKeys(int keySize)
        {
            //using ECDSA algorithm for the key generation
            var gen = new Org.BouncyCastle.Crypto.Generators.ECKeyPairGenerator("ECDSA");

            //Creating Random
            var secureRandom = new SecureRandom();

            //Parameters creation using the random and keysize
            var keyGenParam = new KeyGenerationParameters(secureRandom, keySize);

            //Initializing generation algorithm with the Parameters
            gen.Init(keyGenParam);

            //Generation of Key Pair
            return gen.GenerateKeyPair();
        }

        private void buttonECDH128_Click(object sender, EventArgs e)
        {
            GeneratePKeys(192);
        }

        private void buttonECDH256_Click(object sender, EventArgs e)
        {
            GeneratePKeys(256);
        }

        private void buttonSaveECDH_Click(object sender, EventArgs e)
        {
            if (labelPrivate.Text != "RSA Full Key Pair" && labelPrivate.Text != "ECDH Full Key Pair")
            {
                MessageBox.Show("Incomplete Key Pair");

            }
            else
            {

            }
            // Displays a SaveFileDialog so the user can save the Image
            // assigned to Button2.
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "AllFiles|*.*";
            saveFileDialog1.Title = "Save Private Key";
            saveFileDialog1.ShowDialog();

            // If the file name is not an empty string open it for saving.
            if (saveFileDialog1.FileName != "")
            {
                // Saves the Image via a FileStream created by the OpenFile method.
                System.IO.FileStream fs =
                   (System.IO.FileStream)saveFileDialog1.OpenFile();
                // Saves the Image in the appropriate ImageFormat based upon the
                // File type selected in the dialog box.
                // NOTE that the FilterIndex property is one-based.
                switch (saveFileDialog1.FilterIndex)
                {
                    case 1:
                        var bytePrivate = System.Text.Encoding.UTF8.GetBytes(labelPrivate.Text);
                        fs.Write(bytePrivate, 0, bytePrivate.Length);
                        var bytePub = System.Text.Encoding.UTF8.GetBytes(labelPublic.Text);
                        fs.Write(bytePub, 0, bytePub.Length);
                        break;
                    default: break;

                }

                fs.Close();
            }

        
       
        }
        private void menuEncAes_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormAes(), sender);
            panel2.Height = buttonAes.Height;
            panel2.Top = buttonAes.Top;
            labelTitle.Text = buttonAes.Text;
        }
        private void menuEncTwo_Click(object sender, EventArgs e)
        {

        }

        private void generateECDHKeyPair256bitToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        
    }
}