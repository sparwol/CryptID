﻿using System;
using System.IO;
using System.ComponentModel;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Engines;

namespace Cryptid.Forms
{

    public partial class FormTwofish : Form
    {
        // Declare CspParmeters and RsaCryptoServiceProvider
        // objects with global scope of your Form class.
        CspParameters cspp = new CspParameters();
        RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();

        // Path variables for source, encryption, and
        // decryption folders. Must end with a backslash.
        public const string EncrFolder = @"c:\Encrypt\";
        public const string DecrFolder = @"c:\Decrypt\";
        public const string SrcFolder = @"c:\docs\";

        // Public key file
        public const string PubKeyFile = @"c:\encrypt\rsaPublicKey.txt";

        // Key container name for
        // private/public key value pair.
        const string keyName = "RSA Key";
        public FormTwofish()
        {
            InitializeComponent();
        }

        TwofishEngine Twofish = new TwofishEngine();

    

        private void buttonEncrypt_Click(object sender, EventArgs e)
        {
            if (rsa == null)
            {
                MessageBox.Show("Key not set.");
            }
            else
            {
                // Display a dialog box to select a file to encrypt.
                openFileDialog1.InitialDirectory = Dashboard.SrcFolder;
                openFileDialog1.Title = "Choose file(s) to encrypt";
                openFileDialog1.Multiselect = true;
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    string fName = openFileDialog1.FileName;
                    if (fName != null)
                    {
                        FileInfo fInfo = new FileInfo(fName);
                        // Pass the file name without the path.
                        string name = fInfo.FullName;
                        //twofishEncryptFile(name);

                    }
                }
            }
        }

        // Decrypt Button
        private void buttonDecrypt_Click(object sender, EventArgs e)
        {
            if (rsa == null)
            {
                MessageBox.Show("Key not set.");
            }
            else
            {
                // Display a dialog box to select the encrypted file.
                openFileDialog2.InitialDirectory = Dashboard.EncrFolder;
                if (openFileDialog2.ShowDialog() == DialogResult.OK)
                {
                    string fName = openFileDialog2.FileName;
                    if (fName != null)
                    {
                        FileInfo fi = new FileInfo(fName);
                        string name = fi.Name;
                        //twofishDecryptFile(name);
                    }
                }
            }
        }
    }
}
