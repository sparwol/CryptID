CryptID Incremental Deliverable
15 June 2020

Username: user1
Password: Password123

Estimated Time: 3 hrs
Actual Time: 6 hrs

SQL database setup complete. Password generator functional. Too much trouble with Twofish algorithm... moving to text encryption instead using Rijndael. Elliptic Curve Diffie Hellman key generation is next.

