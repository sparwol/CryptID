﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using Org.BouncyCastle.Asn1.Cms;
using System.Linq;

namespace Cryptid.Forms
{
    public partial class FormText : System.Windows.Forms.Form
    {
        public FormText()
        {
            InitializeComponent();

        }

        // Generate a key k1 with password pwd1 and salt salt1.
        // Generate a key k2 with password pwd1 and salt salt1.
        // Encrypt data1 with key k1 using symmetric encryption, creating edata1.
        // Decrypt edata1 with key k2 using symmetric decryption, creating data2.
        // data2 should equal data1.

        public static void ECrypt(string[] passwordargs, string plain)
        {
            //If no file name is specified, write usage text.
            if (passwordargs.Length < 8)
            {
                MessageBox.Show("Password must be at least 8 characters long.");
            }
            else
            {

                string pwd1 = passwordargs[0];
                // Create a byte array to hold the random value.
                byte[] salt1 = new byte[8];
                using (RNGCryptoServiceProvider rngCsp = new RNGCryptoServiceProvider())
                {
                    // Fill the array with a random value.
                    rngCsp.GetBytes(salt1);
                }

                //data1 can be a string or contents of a file.
                string data1 = plain;
                //The default iteration count is 1000 so the two methods use the same iteration count.
                int myIterations = 1000;
                try
                {
                    Rfc2898DeriveBytes k1 = new Rfc2898DeriveBytes(pwd1, salt1, myIterations);
                    Rfc2898DeriveBytes k2 = new Rfc2898DeriveBytes(pwd1, salt1);
                    // Encrypt the data.
                    Aes encAlg = Aes.Create();
                    encAlg.Key = k1.GetBytes(16);
                    MemoryStream encryptionStream = new MemoryStream();
                    CryptoStream encrypt = new CryptoStream(encryptionStream, encAlg.CreateEncryptor(), CryptoStreamMode.Write);
                    byte[] utfD1 = new System.Text.UTF8Encoding(false).GetBytes(data1);

                    encrypt.Write(utfD1, 0, utfD1.Length);
                    encrypt.FlushFinalBlock();
                    encrypt.Close();
                    byte[] edata1 = encryptionStream.ToArray();
                    k1.Reset();

                    // Decrypt
                    Aes decAlg = Aes.Create();
                    decAlg.Key = k2.GetBytes(16);
                    decAlg.IV = encAlg.IV;
                    MemoryStream decryptionStreamBacking = new MemoryStream();
                    CryptoStream decrypt = new CryptoStream(decryptionStreamBacking, decAlg.CreateDecryptor(), CryptoStreamMode.Write);
                    decrypt.Write(edata1, 0, edata1.Length);
                    decrypt.Flush();
                    decrypt.Close();
                    k2.Reset();
                    string data2 = new UTF8Encoding(false).GetString(decryptionStreamBacking.ToArray());


                }
                catch (Exception e)
                {
                    MessageBox.Show("Error: " + e);
                }
            }
        }


        private void buttonEncrypt_Click(object sender, EventArgs e)
        {
            
            string plain = richPlainText.Text;
            string password = textBoxPassword.Text;
            string[] pass1 = password.ToCharArray().Select(c => c.ToString()).ToArray();
            // Encrypt the string to an array of bytes.
            if (password.Length < 8)
            {
                MessageBox.Show("Password must be at least 8 characters long.");
            }
            else
            {
                // Create a byte array to hold the random value.
                byte[] salt1 = new byte[8];
                using (RNGCryptoServiceProvider rngCsp = new RNGCryptoServiceProvider())
                {
                    // Fill the array with a random value.
                    rngCsp.GetBytes(salt1);
                }

                //data1 can be a string or contents of a file.
                string data1 = plain;
                //The default iteration count is 1000 so the two methods use the same iteration count.
                int myIterations = 1000;
                try
                {
                    Rfc2898DeriveBytes k1 = new Rfc2898DeriveBytes(password, salt1, myIterations);
                    Rfc2898DeriveBytes k2 = new Rfc2898DeriveBytes(password, salt1);
                    // Encrypt the data.
                    Aes encAlg = Aes.Create();
                    encAlg.Key = k1.GetBytes(16);
                    MemoryStream encryptionStream = new MemoryStream();
                    CryptoStream encrypt = new CryptoStream(encryptionStream, encAlg.CreateEncryptor(), CryptoStreamMode.Write);
                    byte[] utfD1 = new System.Text.UTF8Encoding(false).GetBytes(data1);

                    encrypt.Write(utfD1, 0, utfD1.Length);
                    encrypt.FlushFinalBlock();
                    encrypt.Close();
                    byte[] edata1 = encryptionStream.ToArray();
                    k1.Reset();

                    richCipherText.Text = System.Text.Encoding.UTF8.GetString(edata1);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex);
                }
            }
        }

        private void buttonDecrypt_Click(object sender, EventArgs e)
        {
            string cipher = richCipherText.Text;
            string password = textBoxPassword.Text;
            string[] pass1 = password.ToCharArray().Select(c => c.ToString()).ToArray();
            byte[] encrypted = System.Text.Encoding.UTF8.GetBytes(cipher);

            //If no file name is specified, write usage text.
            if (password.Length < 8)
            {
                MessageBox.Show("Password must be at least 8 characters long.");
            }
            else
            {
                // Create a byte array to hold the random value.
                byte[] salt1 = new byte[8];
                using (RNGCryptoServiceProvider rngCsp = new RNGCryptoServiceProvider())
                {
                    // Fill the array with a random value.
                    rngCsp.GetBytes(salt1);
                }

                //data1 can be a string or contents of a file.
                string data1 = cipher;
                //The default iteration count is 1000 so the two methods use the same iteration count.
                int myIterations = 1000;
                try
                {
                    Rfc2898DeriveBytes k1 = new Rfc2898DeriveBytes(password, salt1, myIterations);
                    Rfc2898DeriveBytes k2 = new Rfc2898DeriveBytes(password, salt1);
                    // Encrypt the data.
                    Aes encAlg = Aes.Create();
                    encAlg.Key = k1.GetBytes(16);
                    MemoryStream encryptionStream = new MemoryStream();
                    CryptoStream encrypt = new CryptoStream(encryptionStream, encAlg.CreateEncryptor(), CryptoStreamMode.Write);
                    byte[] utfD1 = new System.Text.UTF8Encoding(false).GetBytes(data1);

                    encrypt.Write(utfD1, 0, utfD1.Length);
                    encrypt.FlushFinalBlock();
                    encrypt.Close();
                    byte[] edata1 = encryptionStream.ToArray();
                    k1.Reset();

                    // Decrypt
                    Aes decAlg = Aes.Create();
                    decAlg.Key = k2.GetBytes(16);
                    decAlg.IV = encAlg.IV;
                    MemoryStream decryptionStreamBacking = new MemoryStream();
                    CryptoStream decrypt = new CryptoStream(decryptionStreamBacking, decAlg.CreateDecryptor(), CryptoStreamMode.Write);
                    decrypt.Write(edata1, 0, edata1.Length);
                    decrypt.Flush();
                    decrypt.Close();
                    k2.Reset();
                    string data2 = new UTF8Encoding(false).GetString(decryptionStreamBacking.ToArray());
                    richCipherText.Text = data2;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex);
                }

                

            }
        }

        
    }
}