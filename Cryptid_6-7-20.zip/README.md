CryptID Incremental Deliverable
7 June 2020

Instructions:
Enter the PIN and Password at the login to enter the Dashboard.

PIN: 123456
PW: Password123

Estimated Time: 3 hrs
Actual Time: 6 hrs

Moving forms including buttons proved challenging. Also the implementation of the Twofish algorithm is not well documented elsewhere.

