CryptID Incremental Deliverable
31 May 2020

Instructions:
Enter the PIN and Password at the login to enter the Dashboard.

PIN: 123456
PW: Password123

Estimated Time: 3 hrs
Actual Time: 3.5 hrs

The UI design and creation of the first functioning child form took about the estimated time. This is because there was designing on paper done beforehand. 

