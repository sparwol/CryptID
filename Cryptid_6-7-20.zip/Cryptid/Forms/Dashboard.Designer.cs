﻿namespace Cryptid
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.buttonAes = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.logoTitle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonTools = new System.Windows.Forms.Button();
            this.buttonTwofish = new System.Windows.Forms.Button();
            this.buttonKeys = new System.Windows.Forms.Button();
            this.button = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.panelMain = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.labelKey = new System.Windows.Forms.Label();
            this.panelKeys = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.labelRsaKeys = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonImportPublicKey = new System.Windows.Forms.Button();
            this.buttonCreateAsmKeys = new System.Windows.Forms.Button();
            this.buttonExportPublicKey = new System.Windows.Forms.Button();
            this.buttonGetPrivateKey = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.encryptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.decryptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.keyMgmtStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.encryptFileUsingTwofishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rSAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ellipticCurveDiffieHellmanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.decryptFileUsingAESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.decryptFileUsingTwofishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panelKeys.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonAes
            // 
            this.buttonAes.FlatAppearance.BorderSize = 0;
            this.buttonAes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAes.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonAes.Location = new System.Drawing.Point(0, 80);
            this.buttonAes.Name = "buttonAes";
            this.buttonAes.Size = new System.Drawing.Size(200, 60);
            this.buttonAes.TabIndex = 5;
            this.buttonAes.Text = "          AES";
            this.buttonAes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAes.UseVisualStyleBackColor = true;
            this.buttonAes.Click += new System.EventHandler(this.buttonAes_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.buttonExit);
            this.panel3.Controls.Add(this.buttonTools);
            this.panel3.Controls.Add(this.buttonTwofish);
            this.panel3.Controls.Add(this.buttonKeys);
            this.panel3.Controls.Add(this.button);
            this.panel3.Controls.Add(this.buttonAes);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 561);
            this.panel3.TabIndex = 11;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(21, 214);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(43, 27);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(21, 156);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(43, 27);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(21, 90);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(43, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Olive;
            this.panel4.Controls.Add(this.logoTitle);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 80);
            this.panel4.TabIndex = 13;
            // 
            // logoTitle
            // 
            this.logoTitle.AutoSize = true;
            this.logoTitle.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.logoTitle.Location = new System.Drawing.Point(53, 19);
            this.logoTitle.Name = "logoTitle";
            this.logoTitle.Size = new System.Drawing.Size(123, 36);
            this.logoTitle.TabIndex = 0;
            this.logoTitle.Text = "CryptID";
            this.logoTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel2.Location = new System.Drawing.Point(0, 80);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(6, 60);
            this.panel2.TabIndex = 12;
            // 
            // buttonExit
            // 
            this.buttonExit.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonExit.FlatAppearance.BorderSize = 0;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonExit.Location = new System.Drawing.Point(0, 501);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(200, 60);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonTools
            // 
            this.buttonTools.FlatAppearance.BorderSize = 0;
            this.buttonTools.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTools.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTools.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonTools.Location = new System.Drawing.Point(0, 260);
            this.buttonTools.Name = "buttonTools";
            this.buttonTools.Size = new System.Drawing.Size(200, 60);
            this.buttonTools.TabIndex = 5;
            this.buttonTools.Text = "          Tools";
            this.buttonTools.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTools.UseVisualStyleBackColor = true;
            this.buttonTools.Click += new System.EventHandler(this.buttonTools_Click);
            // 
            // buttonTwofish
            // 
            this.buttonTwofish.FlatAppearance.BorderSize = 0;
            this.buttonTwofish.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTwofish.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTwofish.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonTwofish.Location = new System.Drawing.Point(0, 140);
            this.buttonTwofish.Name = "buttonTwofish";
            this.buttonTwofish.Size = new System.Drawing.Size(200, 60);
            this.buttonTwofish.TabIndex = 5;
            this.buttonTwofish.Text = "          Twofish";
            this.buttonTwofish.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTwofish.UseVisualStyleBackColor = true;
            this.buttonTwofish.Click += new System.EventHandler(this.buttonTwofish_Click);
            // 
            // buttonKeys
            // 
            this.buttonKeys.FlatAppearance.BorderSize = 0;
            this.buttonKeys.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonKeys.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKeys.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonKeys.Location = new System.Drawing.Point(0, 200);
            this.buttonKeys.Name = "buttonKeys";
            this.buttonKeys.Size = new System.Drawing.Size(200, 60);
            this.buttonKeys.TabIndex = 5;
            this.buttonKeys.Text = "          Keys";
            this.buttonKeys.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonKeys.UseVisualStyleBackColor = true;
            this.buttonKeys.Click += new System.EventHandler(this.buttonKeys_Click);
            // 
            // button
            // 
            this.button.Location = new System.Drawing.Point(0, 0);
            this.button.Name = "button";
            this.button.Size = new System.Drawing.Size(75, 23);
            this.button.TabIndex = 14;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel5.Controls.Add(this.labelTitle);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(200, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(744, 80);
            this.panel5.TabIndex = 13;
            // 
            // labelTitle
            // 
            this.labelTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.labelTitle.Location = new System.Drawing.Point(336, 21);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(85, 34);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "Home";
            this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelMain.Controls.Add(this.panel6);
            this.panelMain.Controls.Add(this.panelKeys);
            this.panelMain.Controls.Add(this.menuStrip1);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(200, 80);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(744, 481);
            this.panelMain.TabIndex = 14;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(96)))), ((int)(((byte)(96)))));
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.labelKey);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Font = new System.Drawing.Font("Gill Sans MT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(0, 448);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(544, 33);
            this.panel6.TabIndex = 27;
            // 
            // labelKey
            // 
            this.labelKey.AutoSize = true;
            this.labelKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelKey.Font = new System.Drawing.Font("Lucida Sans Typewriter", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelKey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelKey.Location = new System.Drawing.Point(12, 9);
            this.labelKey.Name = "labelKey";
            this.labelKey.Size = new System.Drawing.Size(95, 15);
            this.labelKey.TabIndex = 6;
            this.labelKey.Text = "Key Not Set";
            // 
            // panelKeys
            // 
            this.panelKeys.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelKeys.Controls.Add(this.label3);
            this.panelKeys.Controls.Add(this.labelRsaKeys);
            this.panelKeys.Controls.Add(this.label2);
            this.panelKeys.Controls.Add(this.buttonImportPublicKey);
            this.panelKeys.Controls.Add(this.buttonCreateAsmKeys);
            this.panelKeys.Controls.Add(this.buttonExportPublicKey);
            this.panelKeys.Controls.Add(this.buttonGetPrivateKey);
            this.panelKeys.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelKeys.Location = new System.Drawing.Point(544, 26);
            this.panelKeys.Name = "panelKeys";
            this.panelKeys.Size = new System.Drawing.Size(200, 455);
            this.panelKeys.TabIndex = 0;
            this.panelKeys.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Olive;
            this.label3.Location = new System.Drawing.Point(75, 279);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 22);
            this.label3.TabIndex = 31;
            this.label3.Text = "ECDH";
            // 
            // labelRsaKeys
            // 
            this.labelRsaKeys.AutoSize = true;
            this.labelRsaKeys.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRsaKeys.ForeColor = System.Drawing.Color.Olive;
            this.labelRsaKeys.Location = new System.Drawing.Point(78, 60);
            this.labelRsaKeys.Name = "labelRsaKeys";
            this.labelRsaKeys.Size = new System.Drawing.Size(46, 22);
            this.labelRsaKeys.TabIndex = 30;
            this.labelRsaKeys.Text = "RSA";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(0, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 35);
            this.label2.TabIndex = 25;
            this.label2.Text = "Key Management";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonImportPublicKey
            // 
            this.buttonImportPublicKey.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonImportPublicKey.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonImportPublicKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonImportPublicKey.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonImportPublicKey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonImportPublicKey.Location = new System.Drawing.Point(26, 170);
            this.buttonImportPublicKey.Name = "buttonImportPublicKey";
            this.buttonImportPublicKey.Size = new System.Drawing.Size(150, 35);
            this.buttonImportPublicKey.TabIndex = 29;
            this.buttonImportPublicKey.Text = "Import Public Key";
            this.toolTip1.SetToolTip(this.buttonImportPublicKey, "Import public key to encrypt file");
            this.buttonImportPublicKey.UseVisualStyleBackColor = true;
            this.buttonImportPublicKey.Click += new System.EventHandler(this.buttonImportPublicKey_Click);
            // 
            // buttonCreateAsmKeys
            // 
            this.buttonCreateAsmKeys.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonCreateAsmKeys.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonCreateAsmKeys.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateAsmKeys.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonCreateAsmKeys.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonCreateAsmKeys.Location = new System.Drawing.Point(26, 88);
            this.buttonCreateAsmKeys.Name = "buttonCreateAsmKeys";
            this.buttonCreateAsmKeys.Size = new System.Drawing.Size(150, 35);
            this.buttonCreateAsmKeys.TabIndex = 26;
            this.buttonCreateAsmKeys.Text = "Create Keys";
            this.toolTip1.SetToolTip(this.buttonCreateAsmKeys, "Create asymmetric key pair");
            this.buttonCreateAsmKeys.UseVisualStyleBackColor = true;
            this.buttonCreateAsmKeys.Click += new System.EventHandler(this.buttonCreateAsmKeys_Click);
            // 
            // buttonExportPublicKey
            // 
            this.buttonExportPublicKey.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonExportPublicKey.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonExportPublicKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExportPublicKey.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonExportPublicKey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonExportPublicKey.Location = new System.Drawing.Point(26, 129);
            this.buttonExportPublicKey.Name = "buttonExportPublicKey";
            this.buttonExportPublicKey.Size = new System.Drawing.Size(150, 35);
            this.buttonExportPublicKey.TabIndex = 28;
            this.buttonExportPublicKey.Text = "Export Public Key";
            this.toolTip1.SetToolTip(this.buttonExportPublicKey, "Export public key to send for encrypting a file");
            this.buttonExportPublicKey.UseVisualStyleBackColor = true;
            this.buttonExportPublicKey.Click += new System.EventHandler(this.buttonExportPublicKey_Click);
            // 
            // buttonGetPrivateKey
            // 
            this.buttonGetPrivateKey.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonGetPrivateKey.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonGetPrivateKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonGetPrivateKey.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonGetPrivateKey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonGetPrivateKey.Location = new System.Drawing.Point(26, 211);
            this.buttonGetPrivateKey.Name = "buttonGetPrivateKey";
            this.buttonGetPrivateKey.Size = new System.Drawing.Size(150, 35);
            this.buttonGetPrivateKey.TabIndex = 27;
            this.buttonGetPrivateKey.Text = "Get Private Key";
            this.toolTip1.SetToolTip(this.buttonGetPrivateKey, "Get private key to decrypt a sent file");
            this.buttonGetPrivateKey.UseVisualStyleBackColor = true;
            this.buttonGetPrivateKey.Click += new System.EventHandler(this.buttonGetPrivateKey_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Olive;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.encryptToolStripMenuItem,
            this.decryptToolStripMenuItem,
            this.keyMgmtStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(744, 26);
            this.menuStrip1.TabIndex = 28;
            // 
            // encryptToolStripMenuItem
            // 
            this.encryptToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.encryptFileUsingTwofishToolStripMenuItem});
            this.encryptToolStripMenuItem.Font = new System.Drawing.Font("Gill Sans MT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.encryptToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.encryptToolStripMenuItem.Name = "encryptToolStripMenuItem";
            this.encryptToolStripMenuItem.Size = new System.Drawing.Size(62, 22);
            this.encryptToolStripMenuItem.Text = "Encrypt";
            // 
            // decryptToolStripMenuItem
            // 
            this.decryptToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.decryptFileUsingAESToolStripMenuItem,
            this.decryptFileUsingTwofishToolStripMenuItem});
            this.decryptToolStripMenuItem.Font = new System.Drawing.Font("Gill Sans MT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.decryptToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.decryptToolStripMenuItem.Name = "decryptToolStripMenuItem";
            this.decryptToolStripMenuItem.Size = new System.Drawing.Size(64, 22);
            this.decryptToolStripMenuItem.Text = "Decrypt";
            // 
            // keyMgmtStripMenuItem
            // 
            this.keyMgmtStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rSAToolStripMenuItem,
            this.ellipticCurveDiffieHellmanToolStripMenuItem});
            this.keyMgmtStripMenuItem.Font = new System.Drawing.Font("Gill Sans MT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.keyMgmtStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.keyMgmtStripMenuItem.Name = "keyMgmtStripMenuItem";
            this.keyMgmtStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.keyMgmtStripMenuItem.Text = "Key Mangagement";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Font = new System.Drawing.Font("Gill Sans MT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(45, 22);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.fileToolStripMenuItem.Text = "Encrypt File using AES";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // encryptFileUsingTwofishToolStripMenuItem
            // 
            this.encryptFileUsingTwofishToolStripMenuItem.Name = "encryptFileUsingTwofishToolStripMenuItem";
            this.encryptFileUsingTwofishToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.encryptFileUsingTwofishToolStripMenuItem.Text = "Encrypt File using Twofish";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // rSAToolStripMenuItem
            // 
            this.rSAToolStripMenuItem.Name = "rSAToolStripMenuItem";
            this.rSAToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.rSAToolStripMenuItem.Text = "RSA";
            // 
            // ellipticCurveDiffieHellmanToolStripMenuItem
            // 
            this.ellipticCurveDiffieHellmanToolStripMenuItem.Name = "ellipticCurveDiffieHellmanToolStripMenuItem";
            this.ellipticCurveDiffieHellmanToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.ellipticCurveDiffieHellmanToolStripMenuItem.Text = "Elliptic Curve Diffie Hellman";
            // 
            // decryptFileUsingAESToolStripMenuItem
            // 
            this.decryptFileUsingAESToolStripMenuItem.Name = "decryptFileUsingAESToolStripMenuItem";
            this.decryptFileUsingAESToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.decryptFileUsingAESToolStripMenuItem.Text = "Decrypt File using AES";
            // 
            // decryptFileUsingTwofishToolStripMenuItem
            // 
            this.decryptFileUsingTwofishToolStripMenuItem.Name = "decryptFileUsingTwofishToolStripMenuItem";
            this.decryptFileUsingTwofishToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.decryptFileUsingTwofishToolStripMenuItem.Text = "Decrypt File using Twofish";
            // 
            // Dashboard
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(944, 561);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Aqua;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CryptID";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panelKeys.ResumeLayout(false);
            this.panelKeys.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonAes;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonTools;
        private System.Windows.Forms.Button buttonKeys;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label logoTitle;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Button buttonTwofish;
		private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Panel panelKeys;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonImportPublicKey;
        private System.Windows.Forms.Button buttonCreateAsmKeys;
        private System.Windows.Forms.Button buttonExportPublicKey;
        private System.Windows.Forms.Button buttonGetPrivateKey;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label labelKey;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelRsaKeys;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem encryptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem encryptFileUsingTwofishToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem decryptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem keyMgmtStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem decryptFileUsingAESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem decryptFileUsingTwofishToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rSAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ellipticCurveDiffieHellmanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
    }
}

