﻿namespace Cryptid.Forms
{
    partial class FormFile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonDecrypt = new System.Windows.Forms.Button();
            this.buttonEncrypt = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.EncryptDrop = new System.Windows.Forms.Button();
            this.DecryptDrop = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonDecrypt
            // 
            this.buttonDecrypt.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonDecrypt.Cursor = System.Windows.Forms.Cursors.Default;
            this.buttonDecrypt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonDecrypt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDecrypt.Font = new System.Drawing.Font("Gill Sans MT", 12F);
            this.buttonDecrypt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonDecrypt.Location = new System.Drawing.Point(326, 265);
            this.buttonDecrypt.MaximumSize = new System.Drawing.Size(200, 60);
            this.buttonDecrypt.Name = "buttonDecrypt";
            this.buttonDecrypt.Size = new System.Drawing.Size(170, 60);
            this.buttonDecrypt.TabIndex = 23;
            this.buttonDecrypt.Text = "Select file to decrypt";
            this.buttonDecrypt.UseVisualStyleBackColor = true;
            this.buttonDecrypt.Click += new System.EventHandler(this.buttonDecrypt_Click);
            // 
            // buttonEncrypt
            // 
            this.buttonEncrypt.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonEncrypt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonEncrypt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEncrypt.Font = new System.Drawing.Font("Gill Sans MT", 12F);
            this.buttonEncrypt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonEncrypt.Location = new System.Drawing.Point(106, 265);
            this.buttonEncrypt.MaximumSize = new System.Drawing.Size(200, 60);
            this.buttonEncrypt.Name = "buttonEncrypt";
            this.buttonEncrypt.Size = new System.Drawing.Size(170, 60);
            this.buttonEncrypt.TabIndex = 19;
            this.buttonEncrypt.Text = "Select file to encrypt";
            this.buttonEncrypt.UseVisualStyleBackColor = true;
            this.buttonEncrypt.Click += new System.EventHandler(this.buttonEncrypt_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog2_FileOk);
            // 
            // EncryptDrop
            // 
            this.EncryptDrop.AllowDrop = true;
            this.EncryptDrop.Enabled = false;
            this.EncryptDrop.FlatAppearance.BorderColor = System.Drawing.Color.Olive;
            this.EncryptDrop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EncryptDrop.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EncryptDrop.ForeColor = System.Drawing.Color.Olive;
            this.EncryptDrop.Location = new System.Drawing.Point(106, 59);
            this.EncryptDrop.Name = "EncryptDrop";
            this.EncryptDrop.Size = new System.Drawing.Size(170, 170);
            this.EncryptDrop.TabIndex = 24;
            this.EncryptDrop.Text = "Drop file here";
            this.EncryptDrop.UseVisualStyleBackColor = true;
            this.EncryptDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.EncryptDrop_DragDrop);
            this.EncryptDrop.DragOver += new System.Windows.Forms.DragEventHandler(this.EncryptDrop_DragOver);
            // 
            // DecryptDrop
            // 
            this.DecryptDrop.AllowDrop = true;
            this.DecryptDrop.Enabled = false;
            this.DecryptDrop.FlatAppearance.BorderColor = System.Drawing.Color.Olive;
            this.DecryptDrop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DecryptDrop.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DecryptDrop.ForeColor = System.Drawing.Color.Olive;
            this.DecryptDrop.Location = new System.Drawing.Point(326, 59);
            this.DecryptDrop.Name = "DecryptDrop";
            this.DecryptDrop.Size = new System.Drawing.Size(170, 170);
            this.DecryptDrop.TabIndex = 24;
            this.DecryptDrop.Text = "Drop file here";
            this.DecryptDrop.UseVisualStyleBackColor = true;
            // 
            // FormFile
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(600, 400);
            this.Controls.Add(this.DecryptDrop);
            this.Controls.Add(this.EncryptDrop);
            this.Controls.Add(this.buttonEncrypt);
            this.Controls.Add(this.buttonDecrypt);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormFile";
            this.Text = "AES";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonDecrypt;
        private System.Windows.Forms.Button buttonEncrypt;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.Button EncryptDrop;
        private System.Windows.Forms.Button DecryptDrop;
    }
}