CryptID Incremental Deliverable
20 June 2020

user1::Password123
admin::@dm1nP@$$w0rd123



Estimated Time: 3 hrs
Actual Time: 3 hrs

Text encryption working, decryption needs work. UI is tightened and branded. About is fleshed out a bit. Working on drag and drop files for ease of use.

