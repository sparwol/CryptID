﻿namespace Cryptid
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.buttonAes = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.logoTitle = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonTools = new System.Windows.Forms.Button();
            this.buttonTwofish = new System.Windows.Forms.Button();
            this.buttonKeys = new System.Windows.Forms.Button();
            this.button = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.panelMain = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelPublic = new System.Windows.Forms.Label();
            this.labelPrivate = new System.Windows.Forms.Label();
            this.panelKeys = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.labelRsaKeys = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonImportPublicKey = new System.Windows.Forms.Button();
            this.buttonCreateAsmKeys = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.buttonECDH256 = new System.Windows.Forms.Button();
            this.buttonSaveECDH = new System.Windows.Forms.Button();
            this.buttonECDH128 = new System.Windows.Forms.Button();
            this.buttonExportPublicKey = new System.Windows.Forms.Button();
            this.buttonGetPrivateKey = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.encryptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEncAes = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEncTwo = new System.Windows.Forms.ToolStripMenuItem();
            this.keyMgmtStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.rSAToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ellipticCurveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveKeyPairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateECDHKeyPair256bitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.generateECDHKeyPair128bitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createKeyPairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportPublicKeyToFileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.importPublicKeyFromFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getPrivateKeyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.passwordGeneratorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panelKeys.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonAes
            // 
            this.buttonAes.FlatAppearance.BorderSize = 0;
            this.buttonAes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAes.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonAes.Location = new System.Drawing.Point(0, 80);
            this.buttonAes.Name = "buttonAes";
            this.buttonAes.Size = new System.Drawing.Size(200, 60);
            this.buttonAes.TabIndex = 5;
            this.buttonAes.Text = "          AES";
            this.buttonAes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAes.UseVisualStyleBackColor = true;
            this.buttonAes.Click += new System.EventHandler(this.buttonAes_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.buttonExit);
            this.panel3.Controls.Add(this.buttonTools);
            this.panel3.Controls.Add(this.buttonTwofish);
            this.panel3.Controls.Add(this.buttonKeys);
            this.panel3.Controls.Add(this.button);
            this.panel3.Controls.Add(this.buttonAes);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 561);
            this.panel3.TabIndex = 11;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(12, 214);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(52, 40);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 156);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(52, 32);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 90);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(52, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Olive;
            this.panel4.Controls.Add(this.pictureBox5);
            this.panel4.Controls.Add(this.logoTitle);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 80);
            this.panel4.TabIndex = 13;
            // 
            // logoTitle
            // 
            this.logoTitle.AutoSize = true;
            this.logoTitle.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.logoTitle.Location = new System.Drawing.Point(64, 21);
            this.logoTitle.Name = "logoTitle";
            this.logoTitle.Size = new System.Drawing.Size(123, 36);
            this.logoTitle.TabIndex = 0;
            this.logoTitle.Text = "CryptID";
            this.logoTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel2.Location = new System.Drawing.Point(0, 80);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(6, 60);
            this.panel2.TabIndex = 12;
            // 
            // buttonExit
            // 
            this.buttonExit.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonExit.FlatAppearance.BorderSize = 0;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonExit.Location = new System.Drawing.Point(0, 501);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(200, 60);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonTools
            // 
            this.buttonTools.FlatAppearance.BorderSize = 0;
            this.buttonTools.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTools.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTools.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonTools.Location = new System.Drawing.Point(0, 260);
            this.buttonTools.Name = "buttonTools";
            this.buttonTools.Size = new System.Drawing.Size(200, 60);
            this.buttonTools.TabIndex = 5;
            this.buttonTools.Text = "          Tools";
            this.buttonTools.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTools.UseVisualStyleBackColor = true;
            this.buttonTools.Click += new System.EventHandler(this.buttonTools_Click);
            // 
            // buttonTwofish
            // 
            this.buttonTwofish.FlatAppearance.BorderSize = 0;
            this.buttonTwofish.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTwofish.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTwofish.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonTwofish.Location = new System.Drawing.Point(0, 140);
            this.buttonTwofish.Name = "buttonTwofish";
            this.buttonTwofish.Size = new System.Drawing.Size(200, 60);
            this.buttonTwofish.TabIndex = 5;
            this.buttonTwofish.Text = "          Twofish";
            this.buttonTwofish.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTwofish.UseVisualStyleBackColor = true;
            this.buttonTwofish.Click += new System.EventHandler(this.buttonTwofish_Click);
            // 
            // buttonKeys
            // 
            this.buttonKeys.FlatAppearance.BorderSize = 0;
            this.buttonKeys.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonKeys.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKeys.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonKeys.Location = new System.Drawing.Point(0, 200);
            this.buttonKeys.Name = "buttonKeys";
            this.buttonKeys.Size = new System.Drawing.Size(200, 60);
            this.buttonKeys.TabIndex = 5;
            this.buttonKeys.Text = "          Keys";
            this.buttonKeys.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonKeys.UseVisualStyleBackColor = true;
            this.buttonKeys.Click += new System.EventHandler(this.buttonKeys_Click);
            // 
            // button
            // 
            this.button.Location = new System.Drawing.Point(0, 0);
            this.button.Name = "button";
            this.button.Size = new System.Drawing.Size(75, 23);
            this.button.TabIndex = 14;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel5.Controls.Add(this.labelTitle);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(200, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(744, 80);
            this.panel5.TabIndex = 13;
            // 
            // labelTitle
            // 
            this.labelTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.labelTitle.Location = new System.Drawing.Point(336, 21);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(85, 34);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "Home";
            this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelMain.Controls.Add(this.panel6);
            this.panelMain.Controls.Add(this.panelKeys);
            this.panelMain.Controls.Add(this.menuStrip1);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(200, 80);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(744, 481);
            this.panelMain.TabIndex = 14;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(96)))), ((int)(((byte)(96)))));
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.labelPublic);
            this.panel6.Controls.Add(this.labelPrivate);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Font = new System.Drawing.Font("Gill Sans MT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(0, 412);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(544, 69);
            this.panel6.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Lucida Sans Typewriter", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(12, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Private Key: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "Public Key: ";
            // 
            // labelPublic
            // 
            this.labelPublic.AutoSize = true;
            this.labelPublic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPublic.Font = new System.Drawing.Font("Lucida Sans Typewriter", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPublic.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelPublic.Location = new System.Drawing.Point(129, 11);
            this.labelPublic.Name = "labelPublic";
            this.labelPublic.Size = new System.Drawing.Size(95, 15);
            this.labelPublic.TabIndex = 6;
            this.labelPublic.Text = "Key Not Set";
            // 
            // labelPrivate
            // 
            this.labelPrivate.AutoSize = true;
            this.labelPrivate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPrivate.Font = new System.Drawing.Font("Lucida Sans Typewriter", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPrivate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelPrivate.Location = new System.Drawing.Point(129, 38);
            this.labelPrivate.Name = "labelPrivate";
            this.labelPrivate.Size = new System.Drawing.Size(95, 15);
            this.labelPrivate.TabIndex = 6;
            this.labelPrivate.Text = "Key Not Set";
            // 
            // panelKeys
            // 
            this.panelKeys.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelKeys.Controls.Add(this.label3);
            this.panelKeys.Controls.Add(this.labelRsaKeys);
            this.panelKeys.Controls.Add(this.label2);
            this.panelKeys.Controls.Add(this.buttonImportPublicKey);
            this.panelKeys.Controls.Add(this.buttonCreateAsmKeys);
            this.panelKeys.Controls.Add(this.button2);
            this.panelKeys.Controls.Add(this.buttonECDH256);
            this.panelKeys.Controls.Add(this.buttonSaveECDH);
            this.panelKeys.Controls.Add(this.buttonECDH128);
            this.panelKeys.Controls.Add(this.buttonExportPublicKey);
            this.panelKeys.Controls.Add(this.buttonGetPrivateKey);
            this.panelKeys.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelKeys.Location = new System.Drawing.Point(544, 26);
            this.panelKeys.Name = "panelKeys";
            this.panelKeys.Size = new System.Drawing.Size(200, 455);
            this.panelKeys.TabIndex = 0;
            this.panelKeys.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Olive;
            this.label3.Location = new System.Drawing.Point(75, 279);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 22);
            this.label3.TabIndex = 31;
            this.label3.Text = "ECDH";
            // 
            // labelRsaKeys
            // 
            this.labelRsaKeys.AutoSize = true;
            this.labelRsaKeys.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRsaKeys.ForeColor = System.Drawing.Color.Olive;
            this.labelRsaKeys.Location = new System.Drawing.Point(78, 60);
            this.labelRsaKeys.Name = "labelRsaKeys";
            this.labelRsaKeys.Size = new System.Drawing.Size(46, 22);
            this.labelRsaKeys.TabIndex = 30;
            this.labelRsaKeys.Text = "RSA";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(0, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 35);
            this.label2.TabIndex = 25;
            this.label2.Text = "Key Management";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonImportPublicKey
            // 
            this.buttonImportPublicKey.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonImportPublicKey.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonImportPublicKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonImportPublicKey.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonImportPublicKey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonImportPublicKey.Location = new System.Drawing.Point(26, 170);
            this.buttonImportPublicKey.Name = "buttonImportPublicKey";
            this.buttonImportPublicKey.Size = new System.Drawing.Size(150, 35);
            this.buttonImportPublicKey.TabIndex = 29;
            this.buttonImportPublicKey.Text = "Import Public Key";
            this.toolTip1.SetToolTip(this.buttonImportPublicKey, "Import public key to encrypt file");
            this.buttonImportPublicKey.UseVisualStyleBackColor = true;
            this.buttonImportPublicKey.Click += new System.EventHandler(this.buttonImportPublicKey_Click);
            // 
            // buttonCreateAsmKeys
            // 
            this.buttonCreateAsmKeys.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonCreateAsmKeys.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonCreateAsmKeys.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateAsmKeys.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonCreateAsmKeys.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonCreateAsmKeys.Location = new System.Drawing.Point(26, 88);
            this.buttonCreateAsmKeys.Name = "buttonCreateAsmKeys";
            this.buttonCreateAsmKeys.Size = new System.Drawing.Size(150, 35);
            this.buttonCreateAsmKeys.TabIndex = 26;
            this.buttonCreateAsmKeys.Text = "Create Keys";
            this.toolTip1.SetToolTip(this.buttonCreateAsmKeys, "Create asymmetric key pair");
            this.buttonCreateAsmKeys.UseVisualStyleBackColor = true;
            this.buttonCreateAsmKeys.Click += new System.EventHandler(this.buttonCreateAsmKeys_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button2.Location = new System.Drawing.Point(26, 602);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 35);
            this.button2.TabIndex = 28;
            this.button2.Text = "Create 256-bit Key";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.buttonECDH256_Click);
            // 
            // buttonECDH256
            // 
            this.buttonECDH256.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonECDH256.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonECDH256.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonECDH256.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonECDH256.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonECDH256.Location = new System.Drawing.Point(26, 345);
            this.buttonECDH256.Name = "buttonECDH256";
            this.buttonECDH256.Size = new System.Drawing.Size(150, 35);
            this.buttonECDH256.TabIndex = 28;
            this.buttonECDH256.Text = "Create 256-bit Key";
            this.buttonECDH256.UseVisualStyleBackColor = true;
            this.buttonECDH256.Click += new System.EventHandler(this.buttonECDH256_Click);
            // 
            // buttonSaveECDH
            // 
            this.buttonSaveECDH.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonSaveECDH.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonSaveECDH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveECDH.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonSaveECDH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonSaveECDH.Location = new System.Drawing.Point(26, 386);
            this.buttonSaveECDH.Name = "buttonSaveECDH";
            this.buttonSaveECDH.Size = new System.Drawing.Size(150, 35);
            this.buttonSaveECDH.TabIndex = 28;
            this.buttonSaveECDH.Text = "Export ECDH Key";
            this.buttonSaveECDH.UseVisualStyleBackColor = true;
            this.buttonSaveECDH.Click += new System.EventHandler(this.buttonSaveECDH_Click);
            // 
            // buttonECDH128
            // 
            this.buttonECDH128.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonECDH128.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonECDH128.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonECDH128.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonECDH128.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonECDH128.Location = new System.Drawing.Point(26, 304);
            this.buttonECDH128.Name = "buttonECDH128";
            this.buttonECDH128.Size = new System.Drawing.Size(150, 35);
            this.buttonECDH128.TabIndex = 28;
            this.buttonECDH128.Text = "Create 128-bit Key";
            this.buttonECDH128.UseVisualStyleBackColor = true;
            this.buttonECDH128.Click += new System.EventHandler(this.buttonECDH128_Click);
            // 
            // buttonExportPublicKey
            // 
            this.buttonExportPublicKey.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonExportPublicKey.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonExportPublicKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExportPublicKey.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonExportPublicKey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonExportPublicKey.Location = new System.Drawing.Point(26, 129);
            this.buttonExportPublicKey.Name = "buttonExportPublicKey";
            this.buttonExportPublicKey.Size = new System.Drawing.Size(150, 35);
            this.buttonExportPublicKey.TabIndex = 28;
            this.buttonExportPublicKey.Text = "Export Public Key";
            this.toolTip1.SetToolTip(this.buttonExportPublicKey, "Export public key to send for encrypting a file");
            this.buttonExportPublicKey.UseVisualStyleBackColor = true;
            this.buttonExportPublicKey.Click += new System.EventHandler(this.buttonExportPublicKey_Click);
            // 
            // buttonGetPrivateKey
            // 
            this.buttonGetPrivateKey.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.buttonGetPrivateKey.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonGetPrivateKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonGetPrivateKey.Font = new System.Drawing.Font("Gill Sans MT", 11F);
            this.buttonGetPrivateKey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonGetPrivateKey.Location = new System.Drawing.Point(26, 211);
            this.buttonGetPrivateKey.Name = "buttonGetPrivateKey";
            this.buttonGetPrivateKey.Size = new System.Drawing.Size(150, 35);
            this.buttonGetPrivateKey.TabIndex = 27;
            this.buttonGetPrivateKey.Text = "Get Private Key";
            this.toolTip1.SetToolTip(this.buttonGetPrivateKey, "Get private key to decrypt a sent file");
            this.buttonGetPrivateKey.UseVisualStyleBackColor = true;
            this.buttonGetPrivateKey.Click += new System.EventHandler(this.buttonGetPrivateKey_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Olive;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.encryptToolStripMenuItem,
            this.keyMgmtStripMenuItem,
            this.toolsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(744, 26);
            this.menuStrip1.TabIndex = 28;
            // 
            // encryptToolStripMenuItem
            // 
            this.encryptToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuEncAes,
            this.menuEncTwo});
            this.encryptToolStripMenuItem.Font = new System.Drawing.Font("Gill Sans MT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.encryptToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.encryptToolStripMenuItem.Name = "encryptToolStripMenuItem";
            this.encryptToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.encryptToolStripMenuItem.Text = "Encrypt/Decrypt";
            // 
            // menuEncAes
            // 
            this.menuEncAes.Name = "menuEncAes";
            this.menuEncAes.Size = new System.Drawing.Size(180, 22);
            this.menuEncAes.Text = "Encrypt File";
            this.menuEncAes.Click += new System.EventHandler(this.menuEncAes_Click);
            // 
            // menuEncTwo
            // 
            this.menuEncTwo.Name = "menuEncTwo";
            this.menuEncTwo.Size = new System.Drawing.Size(180, 22);
            this.menuEncTwo.Text = "Encrypt Text";
            // 
            // keyMgmtStripMenuItem
            // 
            this.keyMgmtStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rSAToolStripMenuItem1,
            this.ellipticCurveToolStripMenuItem});
            this.keyMgmtStripMenuItem.Font = new System.Drawing.Font("Gill Sans MT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.keyMgmtStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.keyMgmtStripMenuItem.Name = "keyMgmtStripMenuItem";
            this.keyMgmtStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.keyMgmtStripMenuItem.Text = "Key Mangagement";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Font = new System.Drawing.Font("Gill Sans MT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(45, 22);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // rSAToolStripMenuItem1
            // 
            this.rSAToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createKeyPairToolStripMenuItem,
            this.exportPublicKeyToFileToolStripMenuItem1,
            this.importPublicKeyFromFileToolStripMenuItem,
            this.getPrivateKeyToolStripMenuItem});
            this.rSAToolStripMenuItem1.Name = "rSAToolStripMenuItem1";
            this.rSAToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.rSAToolStripMenuItem1.Text = "RSA";
            // 
            // ellipticCurveToolStripMenuItem
            // 
            this.ellipticCurveToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.generateECDHKeyPair128bitToolStripMenuItem,
            this.generateECDHKeyPair256bitToolStripMenuItem1,
            this.saveKeyPairToolStripMenuItem});
            this.ellipticCurveToolStripMenuItem.Name = "ellipticCurveToolStripMenuItem";
            this.ellipticCurveToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ellipticCurveToolStripMenuItem.Text = "Elliptic Curve";
            // 
            // saveKeyPairToolStripMenuItem
            // 
            this.saveKeyPairToolStripMenuItem.Name = "saveKeyPairToolStripMenuItem";
            this.saveKeyPairToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.saveKeyPairToolStripMenuItem.Text = "Save Key Pair";
            // 
            // generateECDHKeyPair256bitToolStripMenuItem1
            // 
            this.generateECDHKeyPair256bitToolStripMenuItem1.Name = "generateECDHKeyPair256bitToolStripMenuItem1";
            this.generateECDHKeyPair256bitToolStripMenuItem1.Size = new System.Drawing.Size(266, 22);
            this.generateECDHKeyPair256bitToolStripMenuItem1.Text = "Generate ECDH Key Pair (256-bit)";
            // 
            // generateECDHKeyPair128bitToolStripMenuItem
            // 
            this.generateECDHKeyPair128bitToolStripMenuItem.Name = "generateECDHKeyPair128bitToolStripMenuItem";
            this.generateECDHKeyPair128bitToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.generateECDHKeyPair128bitToolStripMenuItem.Text = "Generate ECDH Key Pair (128-bit)";
            // 
            // createKeyPairToolStripMenuItem
            // 
            this.createKeyPairToolStripMenuItem.Name = "createKeyPairToolStripMenuItem";
            this.createKeyPairToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.createKeyPairToolStripMenuItem.Text = "Create Key Pair";
            // 
            // exportPublicKeyToFileToolStripMenuItem1
            // 
            this.exportPublicKeyToFileToolStripMenuItem1.Name = "exportPublicKeyToFileToolStripMenuItem1";
            this.exportPublicKeyToFileToolStripMenuItem1.Size = new System.Drawing.Size(225, 22);
            this.exportPublicKeyToFileToolStripMenuItem1.Text = "Export Public Key to File";
            // 
            // importPublicKeyFromFileToolStripMenuItem
            // 
            this.importPublicKeyFromFileToolStripMenuItem.Name = "importPublicKeyFromFileToolStripMenuItem";
            this.importPublicKeyFromFileToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.importPublicKeyFromFileToolStripMenuItem.Text = "Import Public Key from File";
            // 
            // getPrivateKeyToolStripMenuItem
            // 
            this.getPrivateKeyToolStripMenuItem.Name = "getPrivateKeyToolStripMenuItem";
            this.getPrivateKeyToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.getPrivateKeyToolStripMenuItem.Text = "Get Private Key";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.passwordGeneratorToolStripMenuItem});
            this.toolsToolStripMenuItem.Font = new System.Drawing.Font("Gill Sans MT", 9.75F);
            this.toolsToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(50, 22);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // passwordGeneratorToolStripMenuItem
            // 
            this.passwordGeneratorToolStripMenuItem.Name = "passwordGeneratorToolStripMenuItem";
            this.passwordGeneratorToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.passwordGeneratorToolStripMenuItem.Text = "Password Generator";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(12, 276);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(52, 40);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 15;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(13, 17);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(52, 53);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // Dashboard
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(944, 561);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Aqua;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CryptID";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panelKeys.ResumeLayout(false);
            this.panelKeys.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonAes;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonTools;
        private System.Windows.Forms.Button buttonKeys;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label logoTitle;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Button buttonTwofish;
		private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Panel panelKeys;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonImportPublicKey;
        private System.Windows.Forms.Button buttonCreateAsmKeys;
        private System.Windows.Forms.Button buttonExportPublicKey;
        private System.Windows.Forms.Button buttonGetPrivateKey;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label labelPrivate;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelRsaKeys;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem encryptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuEncAes;
        private System.Windows.Forms.ToolStripMenuItem menuEncTwo;
        private System.Windows.Forms.ToolStripMenuItem keyMgmtStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button buttonECDH256;
        private System.Windows.Forms.Button buttonECDH128;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button buttonSaveECDH;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelPublic;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem rSAToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ellipticCurveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveKeyPairToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.ToolStripMenuItem createKeyPairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportPublicKeyToFileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem importPublicKeyFromFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem getPrivateKeyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generateECDHKeyPair128bitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generateECDHKeyPair256bitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem passwordGeneratorToolStripMenuItem;
    }
}

